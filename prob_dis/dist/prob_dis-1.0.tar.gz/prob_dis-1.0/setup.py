from setuptools import setup

setup(
	name = 'prob_dis',
	version = '1.0',
	description = 'Gaussian and Binomial Distributions included',
	packages = ['prob_dis'],
	zip_safe = False
	)
