from .gauss_dis import Gaussian
from .bino_dis import Binomial
